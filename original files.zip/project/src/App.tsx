import React, { useState } from 'react';
import { StudentHeader } from './components/StudentHeader';
import { SemesterCard } from './components/SemesterCard';
import { CGPAChart } from './components/CGPAChart';
import { LoginPage } from './components/LoginPage';
import { calculateCGPA } from './utils/gradeCalculator';
import { students } from './data/students';
import type { Student, LoginCredentials } from './types';

function App() {
  const [currentStudent, setCurrentStudent] = useState<Student | null>(null);
  const [loginError, setLoginError] = useState<string>('');

  const handleLogin = (credentials: LoginCredentials) => {
    const student = students.find(
      s => s.rollNumber === credentials.rollNumber && s.dateOfBirth === credentials.dateOfBirth
    );

    if (student) {
      setCurrentStudent(student);
      setLoginError('');
    } else {
      setLoginError('Invalid registration number or date of birth');
    }
  };

  if (!currentStudent) {
    return <LoginPage onLogin={handleLogin} error={loginError} />;
  }

  const cgpa = calculateCGPA(currentStudent.semesters);
  const totalBacklogs = currentStudent.semesters.reduce(
    (acc, sem) => acc + sem.courses.filter(course => course.isBacklog).length,
    0
  );

  return (
    <div className="min-h-screen bg-gray-100 py-8 px-4 sm:px-6 lg:px-8">
      <div className="max-w-4xl mx-auto">
        <div className="flex justify-end mb-4">
          <button
            onClick={() => setCurrentStudent(null)}
            className="text-sm text-gray-600 hover:text-gray-900"
          >
            Logout
          </button>
        </div>

        <StudentHeader student={currentStudent} />
        
        <div className="grid grid-cols-1 md:grid-cols-2 gap-6 mb-6">
          <div className="bg-white rounded-lg shadow-md p-6">
            <h2 className="text-xl font-semibold text-gray-800 mb-2">Overall Performance</h2>
            <div className="flex justify-between items-center">
              <div>
                <p className="text-gray-600">Cumulative GPA</p>
                <p className="text-3xl font-bold text-blue-600">{cgpa}</p>
              </div>
              <div>
                <p className="text-gray-600">Total Backlogs</p>
                <p className={`text-3xl font-bold ${
                  totalBacklogs > 0 ? 'text-red-600' : 'text-green-600'
                }`}>
                  {totalBacklogs}
                </p>
              </div>
            </div>
          </div>
        </div>

        <CGPAChart semesters={currentStudent.semesters} />

        <div className="space-y-6">
          {currentStudent.semesters.map(semester => (
            <SemesterCard key={semester.id} semester={semester} />
          ))}
        </div>
      </div>
    </div>
  );
}

export default App;