import { Student } from '../types';

export const students: Student[] = [
  {
    id: "1",
    name: "John Doe",
    rollNumber: "CS20B001",
    department: "Computer Science",
    batch: "2020-2024",
    dateOfBirth: "2002-05-15",
    semesters: [
      {
        id: 1,
        semesterNumber: 1,
        courses: [
          { id: 1, name: "Mathematics I", credits: 4, grade: "A", isBacklog: false },
          { id: 2, name: "Physics", credits: 4, grade: "B+", isBacklog: false },
          { id: 3, name: "Programming", credits: 3, grade: "A+", isBacklog: false },
        ]
      },
      {
        id: 2,
        semesterNumber: 2,
        courses: [
          { id: 4, name: "Mathematics II", credits: 4, grade: "B", isBacklog: false },
          { id: 5, name: "Digital Logic", credits: 3, grade: "F", isBacklog: true },
          { id: 6, name: "Data Structures", credits: 4, grade: "A", isBacklog: false },
        ]
      }
    ]
  },
  {
    id: "2",
    name: "Jane Smith",
    rollNumber: "CS20B002",
    department: "Computer Science",
    batch: "2020-2024",
    dateOfBirth: "2002-08-23",
    semesters: [
      {
        id: 1,
        semesterNumber: 1,
        courses: [
          { id: 1, name: "Mathematics I", credits: 4, grade: "A+", isBacklog: false },
          { id: 2, name: "Physics", credits: 4, grade: "A", isBacklog: false },
          { id: 3, name: "Programming", credits: 3, grade: "A+", isBacklog: false },
        ]
      },
      {
        id: 2,
        semesterNumber: 2,
        courses: [
          { id: 4, name: "Mathematics II", credits: 4, grade: "A", isBacklog: false },
          { id: 5, name: "Digital Logic", credits: 3, grade: "B+", isBacklog: false },
          { id: 6, name: "Data Structures", credits: 4, grade: "A+", isBacklog: false },
        ]
      }
    ]
  },
  {
    id: "3",
    name: "Michael Johnson",
    rollNumber: "CS20B003",
    department: "Computer Science",
    batch: "2020-2024",
    dateOfBirth: "2002-03-10",
    semesters: [
      {
        id: 1,
        semesterNumber: 1,
        courses: [
          { id: 1, name: "Mathematics I", credits: 4, grade: "B", isBacklog: false },
          { id: 2, name: "Physics", credits: 4, grade: "C+", isBacklog: false },
          { id: 3, name: "Programming", credits: 3, grade: "B+", isBacklog: false },
        ]
      },
      {
        id: 2,
        semesterNumber: 2,
        courses: [
          { id: 4, name: "Mathematics II", credits: 4, grade: "F", isBacklog: true },
          { id: 5, name: "Digital Logic", credits: 3, grade: "C", isBacklog: false },
          { id: 6, name: "Data Structures", credits: 4, grade: "B", isBacklog: false },
        ]
      }
    ]
  }
];