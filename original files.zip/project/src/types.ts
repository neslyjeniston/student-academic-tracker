export interface Semester {
  id: number;
  courses: Course[];
  semesterNumber: number;
}

export interface Course {
  id: number;
  name: string;
  credits: number;
  grade: string;
  isBacklog: boolean;
}

export interface Student {
  id: string;
  name: string;
  rollNumber: string;
  department: string;
  batch: string;
  dateOfBirth: string;
  semesters: Semester[];
}

export interface LoginCredentials {
  rollNumber: string;
  dateOfBirth: string;
}