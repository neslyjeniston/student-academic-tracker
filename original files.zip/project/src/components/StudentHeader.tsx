import React from 'react';
import { GraduationCap, User, BookOpen, Users } from 'lucide-react';
import { Student } from '../types';

interface StudentHeaderProps {
  student: Student;
}

export const StudentHeader: React.FC<StudentHeaderProps> = ({ student }) => {
  return (
    <div className="bg-white rounded-lg shadow-md p-6 mb-6">
      <div className="flex items-center justify-between">
        <div className="flex items-center space-x-4">
          <div className="h-16 w-16 bg-blue-100 rounded-full flex items-center justify-center">
            <User className="h-8 w-8 text-blue-600" />
          </div>
          <div>
            <h1 className="text-2xl font-bold text-gray-800">{student.name}</h1>
            <div className="flex items-center space-x-4 mt-2 text-gray-600">
              <div className="flex items-center">
                <GraduationCap className="h-4 w-4 mr-2" />
                <span>{student.department}</span>
              </div>
              <div className="flex items-center">
                <BookOpen className="h-4 w-4 mr-2" />
                <span>Roll: {student.rollNumber}</span>
              </div>
              <div className="flex items-center">
                <Users className="h-4 w-4 mr-2" />
                <span>Batch: {student.batch}</span>
              </div>
            </div>
          </div>
        </div>
      </div>
    </div>
  );
};