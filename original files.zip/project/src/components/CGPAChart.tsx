import React from 'react';
import { Semester } from '../types';
import { calculateSemesterGPA } from '../utils/gradeCalculator';

interface CGPAChartProps {
  semesters: Semester[];
}

export const CGPAChart: React.FC<CGPAChartProps> = ({ semesters }) => {
  const gpas = semesters.map(sem => calculateSemesterGPA(sem.courses));
  const maxGPA = Math.max(...gpas, 10);

  return (
    <div className="bg-white rounded-lg shadow-md p-6 mb-6">
      <h2 className="text-xl font-semibold text-gray-800 mb-4">CGPA Progression</h2>
      <div className="h-64 flex items-end space-x-4">
        {gpas.map((gpa, index) => (
          <div key={index} className="flex-1 flex flex-col items-center">
            <div 
              className="w-full bg-blue-500 rounded-t"
              style={{ height: `${(gpa / maxGPA) * 100}%` }}
            >
              <div className="text-white text-center -mt-6">{gpa}</div>
            </div>
            <div className="mt-2 text-sm text-gray-600">Sem {index + 1}</div>
          </div>
        ))}
      </div>
    </div>
  );
};