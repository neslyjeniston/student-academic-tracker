const gradePoints: Record<string, number> = {
  'A+': 10,
  'A': 9,
  'B+': 8,
  'B': 7,
  'C+': 6,
  'C': 5,
  'D': 4,
  'F': 0
};

export const calculateSemesterGPA = (courses: Course[]): number => {
  let totalCredits = 0;
  let totalGradePoints = 0;

  courses.forEach(course => {
    totalCredits += course.credits;
    totalGradePoints += course.credits * (gradePoints[course.grade] || 0);
  });

  return totalCredits === 0 ? 0 : Number((totalGradePoints / totalCredits).toFixed(2));
};

export const calculateCGPA = (semesters: Semester[]): number => {
  let totalCredits = 0;
  let totalGradePoints = 0;

  semesters.forEach(semester => {
    semester.courses.forEach(course => {
      totalCredits += course.credits;
      totalGradePoints += course.credits * (gradePoints[course.grade] || 0);
    });
  });

  return totalCredits === 0 ? 0 : Number((totalGradePoints / totalCredits).toFixed(2));
};